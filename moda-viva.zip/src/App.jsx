import React from "react";

const productos = [
  {
    nombre: "Vestido Floral",
    precio: "S/ 89.90",
    imagen: "http://imgfz.com/i/n6AMpz2.jpeg",
  },
  {
    nombre: "Blusa Estampada",
    precio: "S/ 59.90",
    imagen: "http://imgfz.com/i/zdscNGF.jpeg",
  }
];

export default function App() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-300 via-fuchsia-400 to-rose-300 p-4 font-sans">
      <header className="text-center py-6">
        <h1 className="text-4xl font-bold text-white drop-shadow-lg">Moda Viva</h1>
        <p className="text-white mt-2 text-lg">Tu estilo, tu esencia</p>
      </header>

      <section className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mt-6">
        {productos.map((producto, index) => (
          <div
            key={index}
            className="bg-white p-4 rounded-xl shadow-lg hover:scale-105 transition"
          >
            <img
              src={producto.imagen}
              alt={producto.nombre}
              className="rounded-xl mb-4"
            />
            <h3 className="text-lg font-bold text-pink-700">{producto.nombre}</h3>
            <p className="text-pink-600">{producto.precio}</p>
          </div>
        ))}
      </section>

      <section className="text-center mt-10">
        <a
          href="https://wa.me/51999999999"
          target="_blank"
          rel="noopener noreferrer"
          className="inline-block px-6 py-3 bg-green-500 text-white font-bold rounded-full shadow-md hover:bg-green-600 transition"
        >
          Pedidos por WhatsApp
        </a>
        <br />
        <a
          href="https://www.facebook.com/share/16KFvx2Ent/"
          target="_blank"
          rel="noopener noreferrer"
          className="inline-block mt-4 text-white underline"
        >
          Visítanos en Facebook
        </a>
      </section>

      <footer className="mt-16 text-center text-white text-sm">
        &copy; 2025 Moda Viva - Todos los derechos reservados
      </footer>
    </div>
  );
}
